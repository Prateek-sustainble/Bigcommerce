const express = require('express')
const router  = express.Router()

const BC_API    = () => `https://api.bigcommerce.com/stores/${process.env.BC_STORE_HASH}/v3`
const bcHeaders = () => ({ 'Content-Type':'application/json', 'X-Auth-Token':process.env.BC_ACCESS_TOKEN })

router.post('/', async (req, res) => {
  const { itemNumber, description, unitPriceDisplay, quantity, currency } = req.body
  if (!unitPriceDisplay || !quantity)
    return res.status(400).json({ ok:false, error:'Missing price or quantity.' })
  if (!process.env.BC_STORE_HASH || !process.env.BC_ACCESS_TOKEN)
    return res.status(500).json({ ok:false, error:'BigCommerce credentials not configured in .env' })
  const BC_PRODUCT_ID = parseInt(process.env.BC_PRODUCT_ID || '0')
  if (!BC_PRODUCT_ID)
    return res.status(500).json({ ok:false, error:'BC_PRODUCT_ID not set in .env' })
  try {
    const productRes  = await fetch(`${BC_API()}/catalog/products/${BC_PRODUCT_ID}/variants`, { headers:bcHeaders() })
    const productData = await productRes.json()
    const variantId   = productData?.data?.[0]?.id
    if (!variantId) return res.status(502).json({ ok:false, error:`No variant found for product ${BC_PRODUCT_ID}` })
    const cartRes = await fetch(`${BC_API()}/carts`, {
      method:'POST', headers:bcHeaders(),
      body: JSON.stringify({ line_items:[{ quantity:parseInt(quantity), product_id:BC_PRODUCT_ID, variant_id:variantId, list_price:parseFloat(unitPriceDisplay), name:description||itemNumber }] })
    })
    const cartData = await cartRes.json()
    if (!cartRes.ok) return res.status(502).json({ ok:false, error:cartData?.title||'Failed to create cart.', detail:cartData })
    const cartId = cartData.data?.id
    if (!cartId) return res.status(502).json({ ok:false, error:'No cart ID returned.' })
    const redirectRes  = await fetch(`${BC_API()}/carts/${cartId}/redirect_urls`, { method:'POST', headers:bcHeaders(), body:JSON.stringify({}) })
    const redirectData = await redirectRes.json()
    return res.json({ ok:true, cartId, checkoutUrl:redirectData.data?.checkout_url, cartUrl:redirectData.data?.cart_url })
  } catch(err) {
    return res.status(500).json({ ok:false, error:err.message })
  }
})

module.exports = router
