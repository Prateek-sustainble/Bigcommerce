const express = require('express')
const router  = express.Router()
const { calculatePrice } = require('../lib/pricing/convex-domes')

function validate(body, res) {
  const { customerType, currency,
    widthWhole=0, widthFraction=0, heightWhole=0, heightFraction=0,
    frameId, glazingId, itemId, packagingId, quantity=1 } = body
  const e = (msg) => res.status(400).json({ ok:false, error:msg })
  if (!['guest','contractor','house','special','elite','platinum'].includes(customerType)) return e('Invalid customerType')
  if (!['CAD','USD'].includes(currency)) return e('currency must be CAD or USD')
  
  
  if (!['icm-12', 'icm-18', 'icm-24', 'icm-26', 'icm-30', 'icm-36', 'icm-48', 'ecm-12', 'ecm-18', 'ecm-24', 'ecm-26', 'ecm-30', 'ecm-36', 'spvv-12', 'spvv-18', 'spvv-24', 'spvv-26', 'spvv-30', 'spvv-36', 'spvv-20x30', 'spvv-48'].includes(itemId)) return e(`itemId not valid for Convex & Dome`)
  const qty = Number(quantity)
  if (!Number.isInteger(qty) || qty < 1 || qty > 9999) return e('quantity must be 1–9999')
  return null
}

router.post('/', (req, res) => {
  const err = validate(req.body, res)
  if (err) return
  try {
    const data = calculatePrice({ ...req.body, series:'convex' })
    return res.json({ ok:true, data })
  } catch(e) {
    return res.status(422).json({ ok:false, error:e.message })
  }
})

module.exports = router
