const express = require('express')
const router  = express.Router()
const { v4: uuidv4 } = require('uuid')

const quoteStore = new Map()

function generateRef() {
  const ts  = Date.now().toString(36).toUpperCase().slice(-6)
  const rnd = Math.random().toString(36).slice(2, 5).toUpperCase()
  return `SMI-${ts}-${rnd}`
}

router.post('/', async (req, res) => {
  const { contactName, email, companyName='', phone='', comments='', ...rest } = req.body
  if (!contactName || !contactName.trim())
    return res.status(400).json({ ok:false, error:'Contact name is required.' })
  if (!email || !email.includes('@'))
    return res.status(400).json({ ok:false, error:'Valid email is required.' })

  const quote = {
    id:        uuidv4(),
    ref:       generateRef(),
    createdAt: new Date().toISOString(),
    status:    'pending',
    contact:   { name:contactName.trim(), email:email.trim().toLowerCase(), company:companyName.trim(), phone:phone.trim(), comments:comments.trim() },
    config:    rest,
  }
  quoteStore.set(quote.ref, quote)
  console.log(`[Quote] ${quote.ref} — ${quote.contact.name} <${quote.contact.email}>`)
  return res.status(201).json({ ok:true, ref:quote.ref, data:{ ref:quote.ref, createdAt:quote.createdAt } })
})

router.get('/:ref', (req, res) => {
  const quote = quoteStore.get(req.params.ref.toUpperCase())
  if (!quote) return res.status(404).json({ ok:false, error:'Quote not found.' })
  return res.json({ ok:true, data:quote })
})

router.get('/', (_req, res) => {
  const list = [...quoteStore.values()].sort((a,b) => new Date(b.createdAt)-new Date(a.createdAt))
  return res.json({ ok:true, count:list.length, data:list })
})

module.exports = router
