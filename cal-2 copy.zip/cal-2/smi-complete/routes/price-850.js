const express = require('express')
const router  = express.Router()
const { calculatePrice } = require('../lib/pricing/series-850')

const VALID_FRACS = [0,0.0625,0.125,0.1875,0.25,0.3125,0.375,0.4375,0.5,0.5625,0.625,0.6875,0.75,0.8125,0.875,0.9375]

function validate(body, res) {
  const { customerType, currency, widthWhole, widthFraction=0, heightWhole, heightFraction=0, frameId, glazingId, packagingId, quantity=1 } = body
  const e = (msg) => res.status(400).json({ ok:false, error:msg })
  if (!['guest','contractor','house','special','elite','platinum'].includes(customerType)) return e('Invalid customerType')
  if (!['CAD','USD'].includes(currency)) return e('currency must be CAD or USD')
  const w = Number(widthWhole), h = Number(heightWhole)
  if (!Number.isInteger(w) || w < 1 || w > 200) return e('widthWhole must be 1–200')
  if (!Number.isInteger(h) || h < 1 || h > 200) return e('heightWhole must be 1–200')
  if (!VALID_FRACS.includes(Number(widthFraction)))  return e('Invalid widthFraction')
  if (!VALID_FRACS.includes(Number(heightFraction))) return e('Invalid heightFraction')
  const FRAMES   = ['ssch','brgo','brbr','brbl']
  const GLAZINGS = ['5mm','6mm','6mmt','ssgl','3mma','6mma','5shs','6shs']
  const PACKS    = ['s2','c1']
  if (!FRAMES.includes(frameId))     return e(`frameId "${frameId}" not valid for Series 850`)
  if (!GLAZINGS.includes(glazingId)) return e(`glazingId "${glazingId}" not valid for Series 850`)
  if (!PACKS.includes(packagingId))  return e(`packagingId "${packagingId}" not valid for Series 850`)
  const qty = Number(quantity)
  if (!Number.isInteger(qty) || qty < 1 || qty > 9999) return e('quantity must be 1–9999')
  return null
}

router.post('/', (req, res) => {
  const err = validate({ ...req.body, series:'850' }, res)
  if (err) return
  try {
    const data = calculatePrice({ ...req.body, series:'850' })
    return res.json({ ok:true, data })
  } catch(e) {
    return res.status(422).json({ ok:false, error:e.message })
  }
})

module.exports = router
