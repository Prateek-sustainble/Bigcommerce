require('dotenv').config()

const express = require('express')
const cors    = require('cors')

// ── Product-specific price routes ─────────────────────────────────────────────
const price850    = require('./routes/price-850')
const price850ft  = require('./routes/price-850ft')
const price3200   = require('./routes/price-3200')
const price3200ft = require('./routes/price-3200ft')
const price3300   = require('./routes/price-3300')
const priceFram   = require('./routes/price-frameless')
const priceCut    = require('./routes/price-cutglass')
const priceShelv  = require('./routes/price-shelves')
const priceConvex = require('./routes/price-convex')

// ── Shared routes ─────────────────────────────────────────────────────────────
const quoteRouter  = require('./routes/quote')
const bcCartRouter = require('./routes/bc-cart')

const app  = express()
const PORT = process.env.PORT || 3000

app.use(cors({ origin: process.env.ALLOWED_ORIGIN || '*' }))
app.use(express.json())
app.use(express.static('.'))

// ── Product price routes ──────────────────────────────────────────────────────
app.use('/api/price/850',       price850)
app.use('/api/price/850ft',     price850ft)
app.use('/api/price/3200',      price3200)
app.use('/api/price/3200ft',    price3200ft)
app.use('/api/price/3300',      price3300)
app.use('/api/price/frameless', priceFram)
app.use('/api/price/cutglass',  priceCut)
app.use('/api/price/shelves',   priceShelv)
app.use('/api/price/convex',    priceConvex)

// ── Shared routes ─────────────────────────────────────────────────────────────
app.use('/api/quote',   quoteRouter)
app.use('/api/bc-cart', bcCartRouter)

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, ts: new Date().toISOString() })
})

app.listen(PORT, () => {
  console.log(`\n🪞 SMI Backend running at http://localhost:${PORT}\n`)
  console.log(`   POST /api/price/850        — Series 850 Channel Frame`)
  console.log(`   POST /api/price/850ft      — Series 850FT Fixed Tilt`)
  console.log(`   POST /api/price/3200       — Series 3200 Welded Frame`)
  console.log(`   POST /api/price/3200ft     — Series 3200FT Fixed Tilt`)
  console.log(`   POST /api/price/3300       — Series 3300 Frameless SS`)
  console.log(`   POST /api/price/frameless  — Frameless Mirror`)
  console.log(`   POST /api/price/cutglass   — Cut Glass`)
  console.log(`   POST /api/price/shelves    — Steel Shelves`)
  console.log(`   POST /api/price/convex     — Convex & Dome`)
  console.log(`   POST /api/quote            — Submit quote`)
  console.log(`   POST /api/bc-cart          — BigCommerce cart\n`)
})
